# 1. Instalar dependências Python (uma vez)
pip install pandas scikit-learn

# 2. Gerar dataset sintético (uma vez, a partir das regras da Parte A)
python gerar_dataset.py
# -> Gera triagens.csv com ~365 exemplos

# 3. Treinar modelos e exportar base de conhecimento Parte B
python treinar_exportar.py
# -> Gera base_conhecimento_b.pl

# 4. Iniciar o sistema Prolog
swipl main.pl
# -> Dentro do SWI-Prolog:
?- iniciar.


O que se passa em cada triagem (fluxo completo):

1. Sistema pergunta sintomas pela ordem ML (graves primeiro, graças ao bonus clínico)
2. O motor MYCIN avalia em paralelo 36 regras - 30 da Parte A (r_XXX) + 6 da Parte B (dt_NNN)
3. Se score combinado ≥ 0.80, saída antecipada - a certeza MYCIN combina contributos de ambas as partes
4. Resultado final mostra nível, percentagem de confiança e justificação - se a regra principal for dt_NNN, a explicação é gerada automaticamente pelo Python
5. A triagem é guardada em triagens.csv e o Python é chamado para retreinar e regenerar base_conhecimento_b.pl
6. O Prolog recarrega o novo ficheiro sem reiniciar